import RealEstateForm from "@/components/real-estate-form"

export default function Home() {
  return (
    <main className="container mx-auto py-10 px-4">
      <RealEstateForm />
    </main>
  )
}
